use crate::expr::Expr;
use crate::types::Type;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TypeCheckError(pub String);

impl std::fmt::Display for TypeCheckError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl std::error::Error for TypeCheckError {}

pub fn type_check(expr: &Expr) -> Result<Option<Type>, TypeCheckError> {
    match expr {
        Expr::Symbol { ty, .. } | Expr::Variable { ty, .. } | Expr::Atom { ty, .. } => {
            Ok(ty.clone())
        }
        Expr::Apply { head, args } => {
            let mut current = match type_check(head)? {
                Some(ty) => ty,
                None => return Ok(None),
            };
            if args.is_empty() {
                return Ok(Some(current));
            }
            for arg in args {
                match current {
                    Type::Arrow(domain, codomain) => {
                        if let Some(arg_ty) = type_check(arg)? {
                            if *domain != arg_ty {
                                return Err(TypeCheckError(format!(
                                    "Type mismatch in Apply: expected {domain}, got {arg_ty}"
                                )));
                            }
                        }
                        current = *codomain;
                    }
                    other => {
                        return Err(TypeCheckError(format!(
                            "Head {head} has type {other}, expected Arrow"
                        )));
                    }
                }
            }
            Ok(Some(current))
        }
    }
}
