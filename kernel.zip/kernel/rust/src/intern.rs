use std::collections::HashMap;
use std::sync::Arc;

use crate::expr::Expr;

#[derive(Default)]
pub struct Interner {
    nodes: HashMap<Expr, Arc<Expr>>,
}

impl Interner {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn intern(&mut self, expr: Expr) -> Arc<Expr> {
        if let Some(existing) = self.nodes.get(&expr) {
            return existing.clone();
        }
        let shared = Arc::new(expr.clone());
        self.nodes.insert(expr, shared.clone());
        shared
    }

    pub fn len(&self) -> usize {
        self.nodes.len()
    }

    pub fn is_empty(&self) -> bool {
        self.nodes.is_empty()
    }
}
